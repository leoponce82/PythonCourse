# -*- coding: utf-8 -*-
"""
Created on Fri Nov  8 18:57:54 2019

@author: CEClp
"""

print("Holi soy un modulo");
if __name__ =="__main__":
    print("I prefer to be a module")
else:
    print("I like to be a module")
    
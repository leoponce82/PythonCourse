# -*- coding: utf-8 -*-
"""
Created on Fri Nov  8 18:59:39 2019

@author: CEC
"""

import module
import fibonacci
fibonacci.fibonacci(4)

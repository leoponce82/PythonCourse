# -*- coding: utf-8 -*-
"""
Created on Fri Nov  8 20:31:57 2019

@author: CEC
"""
from module import sum1, prod1

zeroes=[0 for i in range(5)]
ones=[1 for i in range(5)]
print(sum1(zeroes))
print(prod1(ones))

